export class payeeDetails{
    pName:string="";
    pAccNum:number=0;
}