import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { FundtransferserviceService } from '../fundtransferservice.service';
import { Account } from '../payee-menu/Account';
import { Payee } from '../payee-menu/Payee';
import { PayeeServiceService } from '../payee-service.service';


@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  constructor(private payeeServ:PayeeServiceService,private fundSer:FundtransferserviceService,private router:Router) { 
    this.getPayeebyAccount();
    this.getAccountDetailsUser();
  }
 
  data:any;
  user:any=sessionStorage.getItem('user');
  username:number=Number(this.user);
  payeeArray:Payee[]=[];
  payeeObj:Payee = new Payee();
  pAccNum:number=0;
  payeeAccount:Account=new Account();
  selfAccount:Account=new Account();
  transferAmount:number=0;
  msg:string="";
  
  getPayeebyAccount(){
    this.payeeServ.getPayeeService(this.username).subscribe(
      (data:Payee[])=>{
        this.payeeArray=data;
      }
    );
  }
  
  getAccountDetails(){
    this.fundSer.getAccountService(this.pAccNum).subscribe(
      (data:Account)=>{
        this.payeeAccount = data;
      }
    );
    this.transferFunds();
  }

  getAccountDetailsUser(){
    this.fundSer.getAccountService(this.username).subscribe(
      (data:Account)=>{
        this.selfAccount=data;
      }
    );
  }

  transferFunds(){
    // this.getAccountDetails();
    if(this.selfAccount.balance<this.transferAmount){
      alert("insufficient balace current balance:"+this.selfAccount.balance);
    }else{
    this.payeeAccount.balance=this.payeeAccount.balance+this.transferAmount;
    this.selfAccount.balance=this.selfAccount.balance-this.transferAmount;

    this.fundSer.setAccountService(this.selfAccount).subscribe(
      (data:any)=>{
        this.msg=data;
      },
      (err)=>{
        console.log(err);
      }
    );
    this.fundSer.setAccountService(this.payeeAccount).subscribe(
      (data:any)=>{
        this.msg=data;
      },
      (err)=>{
        console.log(err);
      }
    );

    sessionStorage.setItem('balance',String(this.selfAccount.balance));
    alert("Transfer sucessfull - current balace is "+this.selfAccount.balance);
     
    }
  }
  
  ngOnInit(): void {
    
  }
  


}
