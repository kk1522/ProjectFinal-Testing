import { StringMapWithRename } from '@angular/compiler/src/compiler_facade_interface';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {

  payeeType:String="";
  show:boolean=false;
  constructor() { }

  ngOnInit(): void {
  }
  toggleIfsc(){
    console.log("toggle");
    console.log(this.payeeType);
    if(this.payeeType==="Own Bank Account"){
        this.show=false;
    }
    else if(this.payeeType==="Other Bank Account"){
      this.show=true;
    }
    
  }
}
