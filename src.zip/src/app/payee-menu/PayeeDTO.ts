import { Payee } from "./Payee";

export class PayeeDTO {

	targetAccountNumber:number=0;
	payeeToAdd: Payee= new Payee();
	
}
